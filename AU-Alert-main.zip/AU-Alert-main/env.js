const API_URL_Live = 'https://au-rep-server.onrender.com';
const API_URL_Local = 'http://localhost:3000';
module.exports = {API_URL_Local, API_URL_Live}