let reportFormData = {
    userid: null,
    image: null,
    title: null,
    location: null,
    locationSpec: null,
    description: null
}

module.exports = {reportFormData}