export default {
  main: {
    text: '#fff',
    background: '#00467F',
  }
};
